<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RestoController;
use App\Http\Controllers\UserController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});
//Route::get('add',[RestoController::class,'add']);

Route::get('home',[RestoController::class,'index']);

//Route::get('/',[RestoController::class,'login']);//new added for login purpose

Route::post('insert',[RestoController::class,'insert']);

Route::get('delete/{id}',[RestoController::class,'delete']);

//Route::get('edit/{id}',[RestoController::class,'edit']);
//
//Route::post('edit/{id}',[RestoController::class,'update']);

Route::get('/',function(){
	return view('login');
});

Route::post('/',function(){
	return view('login');
});

Route::post('login',[UserController::class,'login']);

Route::post('loginfail',[UserController::class,'view']);

//Route::post('login',[UserController::class,'login']);//new added for login purpose

Route::get('logout', function () {
   Session::forget('email');
	return redirect('/');
});

Route::group(['middleware'=>['protectPage']],function(){
	
	Route::get('add',[RestoController::class,'add']);
	
	Route::get('edit/{id}',[RestoController::class,'edit']);

Route::post('edit/{id}',[RestoController::class,'update']);

	
});

Route::get('join',[RestoController::class,'join']);

Route::get('search',[RestoController::class,'search']);
















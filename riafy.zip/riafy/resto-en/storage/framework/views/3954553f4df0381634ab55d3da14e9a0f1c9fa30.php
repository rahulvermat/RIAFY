<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
	.container{
		
		justify-content: center;
	}
	
	h2,h3{
		text-align: center;
	}

</style>

<div class="container ">
	<br><br>
	<h2>Registeration</h2>
	
<form method="post" action="edit">
	<?php echo csrf_field(); ?>
	<div class="row ">
		<div class="col-sm-3"></div>
		<div class="col-sm-6">
		<input type="hidden" name="id" value="<?php echo e($logins['id']); ?>">
		  <!-- Email input -->
  <div class="form-group">
	  <label class="form-label" for="form1Example1">Email address</label>
    <input type="email" id="form1Example1" value="<?php echo e($logins['email']); ?>" name="email" class="form-control" />
    <span style="color:red"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
  </div>
	
		
		
		</div>
	<div class="col-sm-3"></div>
	
	</div>
		
	<div class="row">
		<div class="col-sm-3"></div>
		<div class="col-sm-6">
	
	  <label class="form-label" for="form1Example1">Username</label>
    <input type="text" id="form1Example1" value="<?php echo e($logins['username']); ?>" name="username" class="form-control" />
    <span style="color:red"><?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
 
</div>
	<div class="col-sm-3"></div>
	
	</div>
	
	<div class="row">
		<div class="col-sm-3"></div>
		<div class="col-sm-6">
  <!-- Password input -->
  <div class="form-outline mb-2">
	  <label class="form-label" for="form1Example2">Password</label>
    <input type="text" id="form1Example2" value="<?php echo e($logins['password']); ?>" name="password" class="form-control" />
    <span style="color:red"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
  </div>
</div>
	<div class="col-sm-3"></div>
	</div>
  <!-- 2 column grid layout for inline styling -->
<input type="hidden" name="user_id" value="<?php echo e($logins['user_id']); ?>">
<br><br>
	<div class="row">
		<div class="col-sm-3"></div>
		<div class="col-sm-6">
  <!-- Password input -->
  <div class="form-outline mb-2">
  <!-- Submit button -->
  <button type="submit" class="btn btn-primary btn-block">Sign in</button>
	  </div>
    </div>
		<div class="col-sm-3"></div>
</form>
	</div><?php /**PATH C:\xampp\htdocs\resto-en\resources\views/edit.blade.php ENDPATH**/ ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>

	h2{
		text-align: center;
	}

</style>
<br><br>
<h2>National Stock Exchange (NSE) </h2>
<div class="container-fluid">
<br><br>
	
<table class="table">
  <thead>
    <tr>
      <th>Symbol</th>
      <th>CA</th>

      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>LTP</th>
      <th>Chng</th>
      <th>% Chng</th>
      <th>Volume
(lacs)</th>
      <th>Turnover
(crs.)</th>
      <th>52w H</th>
      <th>52w L</th>
      <th>Past
365 Days</th>
      <th>365 d
% chngA</th>
      <th>Past
30 Days</th>
      <th>30 d
% chng</th>
     
    </tr>
  </thead>
  <tbody>
	   
	 
	  
	 
	  
	  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($user->symbol); ?></td>
      <td><?php echo e($user->ca); ?></td>

      <td><?php echo e($user->today); ?></td>
      <td><?php echo e($user->open); ?></td>
      <td><?php echo e($user->high); ?></td>
      <td><?php echo e($user->low); ?></td>
      <td><?php echo e($user->ltp); ?></td>
      <td><?php echo e($user->chng); ?></td>
      <td><?php echo e($user->chng_per); ?></td>
      <td><?php echo e($user->volume); ?></td>
      <td><?php echo e($user->turnover); ?></td>
      <td><?php echo e($user->five_two_w_h); ?></td>
      <td><?php echo e($user->five_two_w_y); ?></td>
      <td><?php echo e($user->part_one_year); ?></td>

      <td><?php echo e($user->year_per_change); ?></td>
      <td><?php echo e($user->part_mon_days); ?></td>
      <td><?php echo e($user->mon_per_change); ?></td>

      
    </tr>
	  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
  </tbody>
</table>
	</div><?php /**PATH C:\xampp\htdocs\resto-en\resources\views/search-result.blade.php ENDPATH**/ ?>
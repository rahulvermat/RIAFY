@include('header')

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>

	h2{
		text-align: center;
	}

</style>
<br><br>
<h2>National Stock Exchange (NSE) </h2>
<div class="container-fluid">
<br><br>
	
<table class="table">
  <thead>
    <tr>
      <th>Symbol</th>
      <th>CA</th>

      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>LTP</th>
      <th>Chng</th>
      <th>% Chng</th>
      <th>Volume
(lacs)</th>
      <th>Turnover
(crs.)</th>
      <th>52w H</th>
      <th>52w L</th>
      <th>Past
365 Days</th>
      <th>365 d
% chngA</th>
      <th>Past
30 Days</th>
      <th>30 d
% chng</th>
     
    </tr>
  </thead>
  <tbody>
	   
	 
	  
	 
	  
	  @foreach($users as $user)
    <tr>
      <td>{{$user->symbol}}</td>
      <td>{{$user->ca}}</td>

      <td>{{$user->today}}</td>
      <td>{{$user->open}}</td>
      <td>{{$user->high}}</td>
      <td>{{$user->low}}</td>
      <td>{{$user->ltp}}</td>
      <td>{{$user->chng}}</td>
      <td>{{$user->chng_per}}</td>
      <td>{{$user->volume}}</td>
      <td>{{$user->turnover}}</td>
      <td>{{$user->five_two_w_h}}</td>
      <td>{{$user->five_two_w_y}}</td>
      <td>{{$user->part_one_year}}</td>

      <td>{{$user->year_per_change}}</td>
      <td>{{$user->part_mon_days}}</td>
      <td>{{$user->mon_per_change}}</td>

      
    </tr>
	  
  @endforeach
	  
  </tbody>
</table>
	</div>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<style>
	body {
    background-color: grey
}
	</style>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark"> <a class="navbar-brand" href="#" data-abc="true">BBBOOTSTRAP</a> <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse" id="navbarColor02">
        <ul class="navbar-nav mr-auto">
            <!-- <li class="nav-item active"> <a class="nav-link" href="home" data-abc="true">Home <span class="sr-only">(current)</span></a> </li>
            <li class="nav-item"> <a class="nav-link" href="add" data-abc="true">Add New</a> </li>
            <li class="nav-item"> <a class="nav-link" href="#" data-abc="true">Pricing</a> </li>
            <li class="nav-item"> <a class="nav-link" href="#" data-abc="true">Social</a> </li> -->
        </ul>
        <form action="search"  class="form-inline my-2 my-lg-0">
			
	<input class="form-control mr-sm-2" type="text" placeholder="Search" name="query"> 
			
			<button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button> </form>
    </div>
		
	<div class="collapse navbar-collapse" href="" id="navbarColor02" >
		@if(session('email'))
		
		<a href="logout"><input type="button" class="form-control" value="Logout"></a>
		
		@else
		<a href=""><input type="button" class="form-control" value="Hello"></a>
		@endif
		</div>	
		
</nav>
</body>
</html>
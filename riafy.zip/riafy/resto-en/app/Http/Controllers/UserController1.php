<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Track;
class UserController extends Controller
{
    //
	
	function login(Request $req){
		$user= User::where(['email'=>$req->email])->first();
		
		if(!$user || !Hash::check($req->password,$user->password)){
			$req->session()->flash('email',$req->email);
			return redirect('/');
		}else{
			$req->session()->put('email',$req->email);
			//$req->session()->flash('email',$req->email);
			//$req->session()->put('email',$req->email);
			
			//track starts
			
			$insert=new Track();
		
		$insert->email=$req->email;
		
		$insert->save();
			
			//track ends
			return redirect('home');
		}
		
		
	}
	
	function view(){
		
		return "login failed";
		
	}
	
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\login;
use Session;
use Illuminate\Support\Facades\DB;
use App\Models\User;
class RestoController extends Controller
{
    //function index(){
//		
//		$data=Login::all();
//		return view("home",['users'=>$data]);
//		
//	}
	
	
	function index(){
		
		//$userId=Session::get('email')['id']; // taking user id
		//$userId=Session::get('id');//['id']; // taking user id 
		//$userId = 1;
		// $data = DB::table('users')
		// 	->join('login','users.id','=','login.user_id')
		// 	->where('login.user_id',$userId)
		// 	->get();
		
		// return view("home",['users'=>$data]);

		$data=login::all()->sortByDesc("id");

		return view('home',['users'=>$data]);
	}
	
	
	function add(){
		return view("add");
	}
	
	function insert(Request $req){
		
		 $validated = $req->validate([
        'email' => 'required ',
        'username' => 'required',
			 'password' => 'required'
    ]);
		
		$insert=new Login();
		
		$insert->email=$req->email;
		$insert->username=$req->username;
		$insert->password=$req->password;
		$insert->user_id=$req->user_id;
		$insert->save();
		$req->session()->flash('username',$req->username);
		return redirect('add');
	}
	

	//function delete($id){
//		
//		$data=Login::find($id);
//		
//		$result=$data->delete();
//		
//		return redirect('/');
//	}
	
	function delete(Request $req,$id){
		
		$data=Login::find($id);
		
		$result=$data->delete();
		
		$req->session()->flash('id',$result);
		
		return redirect('home');
	}
	
	function edit($id){
		
		$data=Login::find($id);
		
		return view('edit',['logins'=>$data]);
	}
	
	function update(Request $req){
		
		 $validated = $req->validate([
        'email' => 'required ',
        'username' => 'required',
			 'password' => 'required'
    ]);
		
		$data=Login::find($req->id);
		$data->email=$req->email;
		$data->username=$req->username;
		$data->password=$req->password;
		$data->user_id=$req->user_id;
		$data->save();
		$req->session()->flash('username',$req->username);
		return redirect('home');
	}
	
	
	//function index(){
//		
//		//$userId=Session::get('email')['id']; // taking user id
//		$userId=Session::get('id');//['id']; // taking user id 
//		//$userId = 1;
//		$data = DB::table('users')
//			->join('logins','users.id','=','logins.user_id')
//			->where('logins.user_id',$userId)
//			->get();
//		
//		return view("home",['users'=>$data]);
//	}
	
	//function search(Request $req){
//		//return $req->input();
//		
//		$userId=Session::get('id');//['id']; // taking user id 
//		
//		
//		
//	return	$data = Login::where('email','like','%'.$req->input('query').'%')
//					->where('user_id',$userId)
//					->get();
//	}
	
	
	function search(Request $req){
		//return $req->input();
		
		$userId=Session::get('id');//['id']; // taking user id 
		
		
		
		$data = Login::where('symbol','like','%'.$req->input('query').'%')
					//->where('user_id',$userId)
					->get();
		return view("search-result",['users'=>$data]);
		
	}
	
	
}

-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2021 at 02:57 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resto-laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `login-draft`
--

CREATE TABLE `login-draft` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE `logins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `symbol` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ca` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `today` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ltp` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chng` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chng_per` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `volume` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `turnover` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `five_two_w_h` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `five_two_w_y` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `part_one_year` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `year_per_change` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `part_mon_days` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mon_per_change` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `logins`
--

INSERT INTO `logins` (`id`, `symbol`, `ca`, `today`, `open`, `high`, `low`, `ltp`, `chng`, `chng_per`, `volume`, `turnover`, `five_two_w_h`, `five_two_w_y`, `part_one_year`, `year_per_change`, `part_mon_days`, `mon_per_change`, `created_at`, `updated_at`) VALUES
(1, 'WIPRO', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(2, 'TATAMOTORS', '', '', '325.15', '336.90', '324.25', '336.80', '11.15', '3.42', '412.79', '1,363.56', '357.00', '91.80', '', '241.06', '', '16.36', NULL, NULL),
(3, 'NIFTY 50', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '15,733.60', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL),
(4, 'GRASIM', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(5, 'COALINDIA', '', '', '325.15', '336.90', '324.25', '336.80', '11.15', '3.42', '412.79', '1,363.56', '357.00', '91.80', '', '241.06', '', '16.36', NULL, NULL),
(6, 'BAJAJFINSV', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '15,733.60', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL),
(7, 'ONGC', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(8, 'IOC', '', '', '325.15', '336.90', '324.25', '336.80', '11.15', '3.42', '412.79', '1,363.56', '357.00', '91.80', '', '241.06', '', '16.36', NULL, NULL),
(9, 'LT', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '15,733.60', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL),
(10, 'BAJFINANCE', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(11, 'HEROMOTOCO', '', '', '325.15', '336.90', '324.25', '336.80', '11.15', '3.42', '412.79', '1,363.56', '357.00', '91.80', '', '241.06', '', '16.36', NULL, NULL),
(12, 'ADANIPORTS', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '15,733.60', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL),
(13, 'HDFC', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(14, 'BPCL', '', '', '325.15', '336.90', '324.25', '336.80', '11.15', '', '412.79', '1,363.56', '357.00', '91.80', '', '241.06', '', '16.36', NULL, NULL),
(15, 'TATACONSUM', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '15,733.60', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL),
(16, 'JSWSTEEL', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(17, 'DIVISLAB', '', '', '325.15', '336.90', '324.25', '336.80', '11.15', '3.42', '412.79', '1,363.56', '357.00', '91.80', '', '241.06', '', '16.36', NULL, NULL),
(18, 'TECHM', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '15,733.60', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL),
(19, 'INDUSINDBK', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(20, 'HDFCLIFE', '', '', '325.15', '336.90', '324.25', '336.80', '11.15', '3.42', '412.79', '1,363.56', '357.00', '91.80', '', '241.06', '', '16.36', NULL, NULL),
(21, 'ULTRACEMCO', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '15,733.60', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL),
(22, 'M&M', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(23, 'ITC', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(24, 'MARUTI', '', '', '325.15', '336.90', '324.25', '336.80', '11.15', '3.42', '412.79', '1,363.56', '357.00', '91.80', '', '241.06', '', '16.36', NULL, NULL),
(25, 'BHARTIARTL', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL),
(26, 'SBILIFE', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(27, 'KOTAKBANK', '', '', '325.15', '336.90', '324.25', '336.80', '11.15', '3.42', '412.79', '1,363.56', '357.00', '91.80', '', '241.06', '', '16.36', NULL, NULL),
(28, 'CIPLA', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '15,733.60', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL),
(29, 'POWERGRID', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(30, 'TCS', '', '', '325.15', '336.90', '324.25', '336.80', '11.15', '3.42', '412.79', '1,363.56', '357.00', '91.80', '', '241.06', '', '16.36', NULL, NULL),
(31, 'BRITANNIA', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '15,733.60', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL),
(32, 'BRITANNIA', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(33, 'NTPC', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '15,733.60', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL),
(34, 'TATASTEEL', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(35, 'SUNPHARMA', '', '', '543.50', '545.50', '540.45', '541.35', '2.30', '0.43', '47.72', '258.92', '549.90', '206.30', '', '156.14', '', '12.32', NULL, NULL),
(36, 'INFY', '', '', '325.15', '336.90', '324.25', '336.80', '11.15', '3.42', '412.79', '1,363.56', '', '91.80', '', '241.06', '', '16.36', NULL, NULL),
(37, 'NIFTY 50', '', '', '15,712.50', '15,733.60	', '15,622.35	', '15,670.25', '-20.10', '-0.13	', '4,141.65', '25,362.78', '15,733.60', '9,544.35	', '', '55.74', '', '8.10', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2021_03_07_082841_create_login_table', 1),
(2, '2021_03_21_064700_create__users__table', 1),
(3, '2021_03_24_162228_create_tracks_table', 1),
(4, '2021_04_05_170713_create_logins_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tracks`
--

CREATE TABLE `tracks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tracks`
--

INSERT INTO `tracks` (`id`, `email`, `created_at`, `updated_at`) VALUES
(1, 'rahul@verma.com', '2021-04-05 11:33:44', '2021-04-05 11:33:44'),
(2, 'rahul@verma.com', '2021-04-05 11:35:07', '2021-04-05 11:35:07'),
(3, 'rahul@verma.com', '2021-04-05 11:46:24', '2021-04-05 11:46:24'),
(4, 'rahul@verma.com', '2021-06-05 05:34:15', '2021-06-05 05:34:15'),
(5, 'rahul@verma.com', '2021-06-05 05:42:48', '2021-06-05 05:42:48'),
(6, 'rahul@verma.com', '2021-06-05 05:47:16', '2021-06-05 05:47:16'),
(7, 'rahul@verma.com', '2021-06-05 05:49:30', '2021-06-05 05:49:30'),
(8, 'tony@stark.com', '2021-06-05 05:51:44', '2021-06-05 05:51:44'),
(9, 'rahul@verma.com', '2021-06-05 06:50:47', '2021-06-05 06:50:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'rahul verma', 'rahul@verma.com', '$2y$10$hsyWXuwmtqOMWeTkun2cM.RI8lCSgMkMey.rZBHZEMQjVTmcU.N3O', NULL, NULL),
(2, 'stock', 'user@test.com', '$2y$10$dwhsz8z5kb5uh3psqtas6eRRI46lxQyToreYnKUyz4ST2IprdOUEC', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login-draft`
--
ALTER TABLE `login-draft`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tracks`
--
ALTER TABLE `tracks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login-draft`
--
ALTER TABLE `login-draft`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logins`
--
ALTER TABLE `logins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tracks`
--
ALTER TABLE `tracks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
